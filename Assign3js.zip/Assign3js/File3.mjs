import express from 'express';
import data from './data/data.json' assert { type: 'json' };


const app = express();
const PORT = 3000;

// CRUD operations demonstration
app.post('/create', (req, res) => {
    res.send('Practising .post() HTTP method for "Create"');
});

app.put("/update", (req, res) => {
    res.send('Practising .put() HTTP method for "Update"');
});

app.delete("/delete", (req, res) => {
    res.send('Practising .delete() HTTP method for "Delete"');
});

// Start the server
app.listen(PORT, () => {
    console.log(`Example app listening on port http://localhost:${PORT}`);
});
