import express from 'express';

const app = express();
const PORT = 3000;

// Route for the home page to display a simple message
app.get('/', (req, res) => {
    res.send('<h1>Hello prof , this is pearl </h1>');
});

// Start the server
app.listen(PORT, () => {
    console.log(`Example app listening on port http://localhost:${PORT}`);
});
