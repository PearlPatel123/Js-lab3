// Importing required modules
import express from 'express';
import fs from 'fs';

// Creating an instance of Express application
const app = express();

// Defining the port number
const PORT = 3000;

// Reading the JSON file
const jsonData = JSON.parse(fs.readFileSync('./data/data.json', 'utf-8'));

// Route to display JSON contents
app.get('/cars', (req, res) => {
    res.send(jsonData);
});

// Starting the server
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});
